#include "locomotive.h"
#include "ctrain_handler.h"
#include <iostream>

QSemaphore Locomotive::mutex(1);
int Locomotive::reservedBy = -1;
int Locomotive::usedBy = -1;
QSemaphore Locomotive::criticalSegment(1);

Locomotive::Locomotive() :
    _numero(-1),
    _vitesse(0),
    _enFonction(false)
{

}

Locomotive::Locomotive(int numero, int vitesse) :
    _numero(numero),
    _vitesse(vitesse),
    _enFonction(false)
{

}
//-------///
int Locomotive::numero() const
{
    return _numero;
}

void Locomotive::fixerNumero(int numero)
{
    _numero = numero;
}

int Locomotive::vitesse() const
{
    return _vitesse;
}

void Locomotive::fixerVitesse(int vitesse)
{
    _vitesse = vitesse;

    if (_enFonction)
        mettre_vitesse_progressive(_numero, vitesse);
}

void Locomotive::fixerPosition(int contactAvant, int contactArriere)
{
    assigner_loco(contactAvant, contactArriere, _numero, _vitesse);
}

void Locomotive::afficherMessage(const QString &message)
{
    afficher_message_loco(_numero, qPrintable(message));
}

void Locomotive::allumerPhares()
{
    mettre_fonction_loco(_numero, ALLUME);
}

void Locomotive::eteindrePhares()
{
    mettre_fonction_loco(_numero, ETEINT);
}

void Locomotive::demarrer()
{
    mettre_vitesse_progressive(_numero, _vitesse);
    _enFonction = true;
}

void Locomotive::arreter()
{
    arreter_loco(_numero);
    _enFonction = false;
}
//----//
void Locomotive::inverserSens()
{
    inverser_sens_loco(_numero);
}

void Locomotive::fixerFinTour(int finTour)
{
    _finTour = finTour;
}

void Locomotive::fixerContactCritique(int contactCritique)
{
    _contactCritique = contactCritique;
}

void Locomotive::fixerFinContactCritique(int finContactCritique)
{
    _finContactCritique = finContactCritique;
}

void Locomotive::run()
{
    allumerPhares();
    demarrer();

    while(true)
    {
        attendre_contact(_contactCritique);
        mutex.acquire();
        if(usedBy < 0)
        {
            usedBy = numero();
            criticalSegment.acquire();
            mutex.release();
        }
        else
        {
            mutex.release();
            arreter();
            criticalSegment.acquire();
        }
    }

    /*for(int i = 0; i < 2; i++) {
            if(i%2 != 0) {
                attendre_contact(_finTour);
                inverserSens();
            }

            // attendre le contact de requête
            attendre_contact(_finTour);

            mutex.acquire();
            if(reservedBy < 0 && priority) {
                // si la loco est prioritaire, elle réserve la section critique
                reservedBy = numero();

                if(usedBy < 0) {
                    mutex.release();
                    // si section critique n'est pas occupée, on acquire()
                    criticalSegment.acquire();
                } else {
                    mutex.release();
                }
            } else {
                mutex.release();
            }

            // attendre le contact de section critique
            attendre_contact(_contactCritique);

            // quitte le thread si nécessaire avant le blocage suivant
            if(isInterruptionRequested()) {
                arreter();
                return;
            }

            mutex.acquire();
            if((reservedBy < 0 || reservedBy == numero()) && usedBy < 0) {
                // si le segment n'est pas réservé ni utilisé par une autre loco,
                // on le déclare comme utilisé par nous-même
                usedBy = numero();

                if(reservedBy == numero()) {
                   // si on l'avait déjà réservé, on ne l'acquire pas une 2eme fois
                    mutex.release();
                } else {
                    mutex.release();
                    criticalSegment.acquire();
                }
            } else {
                mutex.release();

                // si le segment est utilisé ou réservé par une autre loco,
                // on s'arrête
                arreter();

                // attend la libération de la section critique
                criticalSegment.acquire();

                // déclare la section comme utilisée par nous même
                mutex.acquire();
                usedBy = numero();
                mutex.release();

                // relance la marche
                demarrer();
            }

            // attendre le contact de sortie de section critique
            attendre_contact(_finContactCritique);

            // libère la résevation et l'utilisation de la section critique
            mutex.acquire();
            reservedBy = -1;
            usedBy = -1;
            mutex.release();

            // release la section critique
            criticalSegment.release();
    }*/

}
